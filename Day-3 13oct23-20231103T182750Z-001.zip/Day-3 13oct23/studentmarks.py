print("Student Marksheet")
name=input("enter student name=")
sql=int(input("enter sql marks="))
python=int(input("enter python marks="))
html=int(input("enter html marks="))
java=int(input("enter java marks="))
css=int(input("enter css marks="))
total=sql+python+html+java+css
print("Total marks=",total)
per=total/5
print("Percentage=",per)
if per<=100 and per>80:
    print("O grade")
elif per<=80 and per>60:
    print("A grade")
elif per<=60 and per>40:
    print("B grade")
elif per<=40 and per>0:
    print("Failed")
elif per<0:
    print("Incorrect percentage")
else:
    print("Percentage cannot be greater than 100")
