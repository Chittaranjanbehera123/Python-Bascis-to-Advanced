#WAP to show square and cube of any integer number
n=int(input("enter number greater than zero="))
square=n*n
cube=n*n*n
print(f"Square of {n}={square}")
print(f"Cube of {n}={cube}")
