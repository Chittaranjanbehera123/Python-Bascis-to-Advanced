#WAP to show square and cube of any integer number
n=int(input("enter number greater than zero="))
if n>0:
    square=n*n
    cube=n*n*n
    print(f"Square of {n}={square}")
    print(f"Cube of {n}={cube}")
else:
    if n==0:
        print(f"{n} is not applicable")
    else:
        print(f"{n} must be grater than zero")        
        
